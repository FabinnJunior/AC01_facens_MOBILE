package com.example.ac_01;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import java.util.ArrayList;
import java.util.List;

public class DatabaseHelper extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "livros.db";
    private static final int DATABASE_VERSION = 1;

    // Nome da tabela e colunas
    private static final String TABLE_LIVROS = "livros";
    private static final String COLUMN_ID = "id";
    private static final String COLUMN_TITULO = "titulo";
    private static final String COLUMN_AUTOR = "autor";
    private static final String COLUMN_CATEGORIA = "categoria";
    private static final String COLUMN_LIDO = "lido";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String createTable = "CREATE TABLE " + TABLE_LIVROS + " (" +
                COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COLUMN_TITULO + " TEXT NOT NULL, " +
                COLUMN_AUTOR + " TEXT NOT NULL, " +
                COLUMN_CATEGORIA + " TEXT NOT NULL, " +
                COLUMN_LIDO + " INTEGER NOT NULL)";
        db.execSQL(createTable);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_LIVROS);
        onCreate(db);
    }

    // Adicionar um novo livro ao banco de dados
    public void adicionarLivro(String titulo, String autor, String categoria, boolean lido) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_TITULO, titulo);
        values.put(COLUMN_AUTOR, autor);
        values.put(COLUMN_CATEGORIA, categoria);
        values.put(COLUMN_LIDO, lido ? 1 : 0);

        db.insert(TABLE_LIVROS, null, values);
        db.close();
    }

    // Editar um livro existente
    public void editarLivro(int id, String titulo, String autor, String categoria, boolean lido) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_TITULO, titulo);
        values.put(COLUMN_AUTOR, autor);
        values.put(COLUMN_CATEGORIA, categoria);
        values.put(COLUMN_LIDO, lido ? 1 : 0);

        db.update(TABLE_LIVROS, values, COLUMN_ID + " = ?", new String[]{String.valueOf(id)});
        db.close();
    }

    // Excluir um livro pelo ID
    public void excluirLivro(int id) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(TABLE_LIVROS, COLUMN_ID + " = ?", new String[]{String.valueOf(id)});
        db.close();
    }

    // Buscar todos os livros cadastrados
    public List<Livro> buscarTodosLivros() {
        List<Livro> listaLivros = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM " + TABLE_LIVROS, null);

        if (cursor.moveToFirst()) {
            do {
                int id = cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_ID));
                String titulo = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_TITULO));
                String autor = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_AUTOR));
                String categoria = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_CATEGORIA));
                boolean lido = cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_LIDO)) == 1;

                listaLivros.add(new Livro(id, titulo, autor, categoria, lido));
            } while (cursor.moveToNext());
        }

        cursor.close();
        db.close();
        return listaLivros;
    }
}
