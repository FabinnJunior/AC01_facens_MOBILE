package com.example.ac_01;

import android.content.Intent;
import android.content.res.Configuration;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.Toast;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import java.util.List;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {
    private EditText titleInput, authorInput;
    private Spinner categorySpinner;
    private CheckBox readCheckBox;
    private Button saveButton, languageButton;
    private ListView bookListView;
    private DatabaseHelper databaseHelper;
    private Livro livroSelecionado = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Conectar os elementos da tela
        titleInput = findViewById(R.id.titleInput);
        authorInput = findViewById(R.id.authorInput);
        categorySpinner = findViewById(R.id.categorySpinner);
        readCheckBox = findViewById(R.id.readCheckBox);
        saveButton = findViewById(R.id.saveButton);
        languageButton = findViewById(R.id.languageButton);
        bookListView = findViewById(R.id.bookListView);
        databaseHelper = new DatabaseHelper(this);

        // Configurar Spinner com categorias
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this, R.array.book_categories, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        categorySpinner.setAdapter(adapter);

        // Carregar lista ao iniciar o app
        atualizarListaDeLivros();

        // Botão Salvar/Editar
        saveButton.setOnClickListener(v -> {
            String titulo = titleInput.getText().toString();
            String autor = authorInput.getText().toString();
            String categoria = categorySpinner.getSelectedItem().toString();
            boolean lido = readCheckBox.isChecked();

            if (titulo.isEmpty() || autor.isEmpty()) {
                Toast.makeText(MainActivity.this, R.string.mensagem_preencha_campos, Toast.LENGTH_SHORT).show();
                return;
            }

            if (livroSelecionado == null) {
                databaseHelper.adicionarLivro(titulo, autor, categoria, lido);
            } else {
                databaseHelper.editarLivro(livroSelecionado.getId(), titulo, autor, categoria, lido);
                livroSelecionado = null;
                saveButton.setText(R.string.botao_salvar);
            }

            // Limpar os campos
            titleInput.setText("");
            authorInput.setText("");
            readCheckBox.setChecked(false);
            categorySpinner.setSelection(0);

            // Atualiza a lista na tela
            atualizarListaDeLivros();
        });

        // Clique em um livro para editar
        bookListView.setOnItemClickListener((parent, view, position, id) -> {
            livroSelecionado = (Livro) parent.getItemAtPosition(position);
            titleInput.setText(livroSelecionado.getTitulo());
            authorInput.setText(livroSelecionado.getAutor());
            categorySpinner.setSelection(((ArrayAdapter) categorySpinner.getAdapter()).getPosition(livroSelecionado.getCategoria()));
            readCheckBox.setChecked(livroSelecionado.isLido());
            saveButton.setText(R.string.botao_editar);
        });

        // Pressionar e segurar para excluir um livro
        bookListView.setOnItemLongClickListener((parent, view, position, id) -> {
            Livro livroSelecionado = (Livro) parent.getItemAtPosition(position);

            new AlertDialog.Builder(MainActivity.this)
                    .setTitle(R.string.botao_excluir)
                    .setMessage(R.string.mensagem_excluir)
                    .setPositiveButton("Sim", (dialog, which) -> {
                        databaseHelper.excluirLivro(livroSelecionado.getId());
                        atualizarListaDeLivros();
                    })
                    .setNegativeButton("Não", null)
                    .show();
            return true;
        });

        // Botão para mudar o idioma
        languageButton.setOnClickListener(v -> mudarIdioma());
    }

    private void atualizarListaDeLivros() {
        List<Livro> livros = databaseHelper.buscarTodosLivros();
        ArrayAdapter<Livro> adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, livros);
        bookListView.setAdapter(adapter);
    }

    private void mudarIdioma() {
        String novoIdioma = Locale.getDefault().getLanguage().equals("pt") ? "en" : "pt";
        Locale locale = new Locale(novoIdioma);
        Locale.setDefault(locale);
        Configuration config = new Configuration();
        config.setLocale(locale);
        getResources().updateConfiguration(config, getResources().getDisplayMetrics());

        Intent refresh = new Intent(this, MainActivity.class);
        finish();
        startActivity(refresh);
    }
}
